Exported images from the Photoshop / Photopea psd file - oled_menu_128x64.psd
